 /**
 * @file refranes.cpp
 * @brief Implementación de la clase Refrán
 *
 * @author Mario Rodríguez Ruiz
 * @date Diciembre 2016
 */

#include "refranes.h"

/*******************************
*      Metodos privados        *
*******************************/

void Refranes::AsignaRefran(ArbolGeneral<info>::Nodo n, string refran){
    if(refran.size() > 0){
        if(!ab.hijomasizquierda(n)){//Si no tiene hijos a la izquierda se mete directamente
            //Inicializamos un árbol, O(1)
            ArbolGeneral<info> a;
            //Le asignamos como raíz el nodo a meter, también O(1)
            a.AsignaRaiz(
                //Si refran.size() == 1 term es true, si no es false
                info(refran[0],refran.size() == 1 ? true : false)
            );
            //Metemos el subárbol con el nodo deseado en nuestro árbol.
            //También O(1) ya que siempre metemos árbol de tamaño 1.
            ab.insertar_hijomasizquierda(n,a);
            //Llamamos recursivamente quitando la letra que acabamos de meter y con raíz el nuevo nodo.
            AsignaRefran(ab.hijomasizquierda(n), refran.substr(1));
        }else{
            //Nos pasamos al primer hijo
            n = ab.hijomasizquierda(n);
            //Nos movemos en anchura mientras no coincida la letra y hayan hermanos disponibles
            while((ab.etiqueta(n).c != refran[0]) &&
                  (ab.hermanoderecha(n)) &&
                  (ab.etiqueta(ab.hermanoderecha(n)).c <= refran[0]) //Esta comprobacion/hay que hacerla despues de ver si tiene hermano derecha, ya que si no lo tiene y no corta la comprobación nos meterá un fallo de segmentación.
            ){
                n = ab.hermanoderecha(n);
            }
            //Si coincide la letra, llamamos recursivamente
            if(ab.etiqueta(n).c == refran[0]){
                AsignaRefran(n, refran.substr(1));
            }else{
            //En caso contrario hemos llegado al final del nivel sin encontrarla,
            //o la siguiente letra es mayor alfabéticamente, así que hay que
            //insertar un nuevo subárbol a la derecha.
                //Inicializamos un árbol, O(1)
                ArbolGeneral<info> a;
                //Le asignamos como raíz el nodo a meter, también O(1)
                a.AsignaRaiz(
                    //Si refran.size() == 1 term es true, si no es false
                    info(refran[0],refran.size() == 1 ? true : false)
                );
                //Colocamos el subárbol como hermano a la derecha
                ab.insertar_hermanoderecha(n,a);
                n = ab.hermanoderecha(n);
                //Y llamamos recursivamente sobre dicho subárbol con la cadena restante
                AsignaRefran(n, refran.substr(1));
                ++n_ref ;
            }
        }
    }
}

/******************************
*       Constructores         *
******************************/

//El refran vacío solo tiene una raíz, que no contiene nada.
Refranes::Refranes(){
    ab.AsignaRaiz(info('\0',false));
    n_ref = 1 ;
}

Refranes::Refranes(int lpre){
    len_prefijo = lpre ;
    n_ref = 1 ;
    ab.AsignaRaiz(info('\0',false));
}

//--------------------------------------------------------------------------------

/********************************
*       Metodos publicos        *
********************************/

int Refranes::size() const{
    return n_ref ;
//     int refrans = 0;
//     ArbolGeneral<info>::const_iter_preorden itbeg = ab.begin();
//     ArbolGeneral<info>::const_iter_preorden itend = ab.end();
//     while(itbeg != itend){
//         //Si el nodo contiene una terminacion de refran, se suma uno.
//         if((*itbeg).term) refrans++;
//         ++itbeg;
//     }
//     return refrans;
}

//--------------------------------------------------------------------------------

string Refranes::ObtenerRefranAleatorio(){
    srand( time(0));
    // Se crea una posición aleatoria para obtener un refrán.
    int pos = rand() % size() + 1 ;
//     cout << pos << endl ;
    // Posición que se incrementará al recorrer cada uno de
    // los refranes.
    int pos_bucle = 1 ;

    iterator itbeg = begin();
    iterator itend = end();
    //El vector a devolver
    string result = "";
    while(itbeg != itend && result == ""){
        // Si es term y las posiciones coinciden
        // ya se obtiene el refrán aleatorio.
        // sino, se incrementa la variable de posición.
        if(pos_bucle == pos && (*itbeg.it).term){
            result = itbeg.cad ;
            // Se borra este refrán para que no vuelva a aparecer.
//             BorrarRefran(result) ;
        }
        else if((*itbeg.it).term)
            ++pos_bucle ;

        ++itbeg;
    }
    return result;
}

void Refranes::Insertar(const string & refran){
    AsignaRefran(ab.raiz(), refran) ;
}

pair<bool, Refranes::iterator> Refranes::Esta(const string &refran){
    pair<bool, iterator> res ;
    iterator iter = begin();
    iterator itend = end();
    bool esta = false;
    res.first = esta ;

    while(iter != itend && !esta){
        if(iter.cad == refran && (*iter.it).term){
            esta = true;
            res.first = esta ;
            res.second = iter ;
        }
        ++iter;
    }

    return res ;
}

void Refranes::BorrarRefran(const string &refran){
//     pair<bool, iterator> res = Esta(refran) ;
//
//     if(res.first){
//         ab.destruir(*res.second.ab.it) ;
//         --n_ref ;
//     }

}

/*******************************
*       Metodos iterator       *
*******************************/

string & Refranes::iterator::operator*(){
    return cad;
}

string & Refranes::const_iterator::operator*(){
    return cad;
}

//--------------------------------------------------------------------------------

typename Refranes::iterator & Refranes::iterator::operator++(){
    int prevlevel = it.getlevel();
    ++it;
    if(!it){//si hemos llegado al final del árbol devolvemos end()
        cad = "";
    }else if(prevlevel >= it.getlevel()){
        cad.replace(cad.end() - ((prevlevel + 1) - it.getlevel()), cad.end(), 1, (*it).c);
    }
    else{
        cad.push_back((*it).c);
    }
    return *this;
}

typename Refranes::const_iterator & Refranes::const_iterator::operator++(){
    int prevlevel = it.getlevel();
    ++it;
    if(!it){//si hemos llegado al final del árbol devolvemos end()
        cad = "";
    }else if(prevlevel >= it.getlevel()){
        cad.replace(cad.end() - ((prevlevel + 1) - it.getlevel()), cad.end(), 1, (*it).c);
    }
    else{
        cad.push_back((*it).c);
    }
    return *this;
}

//--------------------------------------------------------------------------------

bool Refranes::iterator::operator==(const iterator & i) const{
    return (i.it == this->it) && (i.cad == this->cad);
}

bool Refranes::const_iterator::operator==(const const_iterator & i) const{
    return (i.it == this->it) && (i.cad == this->cad);
}

//--------------------------------------------------------------------------------

bool Refranes::iterator::operator!=(const iterator & i) const{
    return (i.it != this->it) || (i.cad != this->cad);
}

bool Refranes::const_iterator::operator!=(const const_iterator & i) const{
    return (i.it != this->it) || (i.cad != this->cad);
}

//--------------------------------------------------------------------------------

bool Refranes::iterator::terminal(){
    return (*it).term;
}

bool Refranes::const_iterator::terminal(){
    return (*it).term;
}

//--------------------------------------------------------------------------------

typename Refranes::iterator Refranes::begin(){
    iterator iter;
    iter.it = this->ab.begin();
    iter.cad = "";
    return iter;
}

typename Refranes::const_iterator Refranes::begin() const{
    const_iterator iter;
    iter.it = this->ab.begin();
    iter.cad = "";
    return iter;
}

//--------------------------------------------------------------------------------

typename Refranes::iterator Refranes::end(){
    iterator iter;
    iter.it = this->ab.end();
    iter.cad = "";
    return iter;
}

typename Refranes::const_iterator Refranes::end() const{
    const_iterator iter;
    iter.it = this->ab.end();
    iter.cad = "";
    return iter;
}


/*******************************
*      Entrada y salida        *
*******************************/

istream & operator>>(istream & is, Refranes & D){
    string refran;
    while(!is.eof()){
        getline(is, refran);
        D.Insertar(refran);
    }

    return is;
}

//--------------------------------------------------------------------------------

ostream & operator<<(ostream & os, const Refranes & D){
    Refranes::const_iterator iter = D.begin();
    Refranes::const_iterator itend = D.end();
    ++iter; //pasamos de la raíz, no nos interesa.
    while(iter != itend){
        if(iter.terminal()){
            os << (*iter) << endl;
        }
        ++iter;
    }
    return os;
}
