 
/** @file ArbolGeneral.cpp
 *  @brief Implementación del ArbolGeneral
 *
 *  @author Mario Rodríguez Ruiz
 *  @date Diciembre 2016
 */

#ifndef NULL
#define NULL (void *)0
#endif

#ifndef __ArbolGeneral_cpp__
#define __ArbolGeneral_cpp__

#include "ArbolGeneral.h"

/*******************************
*      Métodos privados        *
*******************************/

template<class Tbase>
void ArbolGeneral<Tbase>::destruir(nodo * n){
    // Si n es válido
    // se destruye recursivamente el subárbol del hijo a la izquierda
    // y el subarbol del hermano a la derecha
    if(n != NULL){
        destruir(n->izqda);
        destruir(n->drcha);
        delete n;
    }
}

//--------------------------------------------------------------------

template<class Tbase>
void ArbolGeneral<Tbase>::copiar(nodo *& dest, nodo * orig){
    // Si orig está vacío se borra en dest.
    if(orig == NULL){
        destruir(dest);
    }
    else{
        // Si dest no existe se crea.
        if(dest == NULL){
            dest = new nodo(orig->etiqueta);
        }
        // Se copia el subarbol hijo-izquierda y el hermano-derecha
        copiar(dest->izqda, orig->izqda);
        if(dest->izqda != NULL){
            // Si hubiera hijo ya, se pone el padre.
            dest->izqda->padre = dest;
        }
        // De igual modo para la derecha.
        copiar(dest->drcha, orig->drcha);
        if(dest->drcha != NULL){
            dest->drcha->padre = dest->padre;
        }
        dest->etiqueta = orig->etiqueta;
    }

}

//--------------------------------------------------------------------

template<class Tbase>
int ArbolGeneral<Tbase>::contar(const nodo * n) const{
    // Si el nodo es válido, éste se cuenta
    // y recursivamente hijo-izq y hermano-der
    if(n != NULL){
        int cont = 1;
        cont += contar(n->izqda);
        cont += contar(n->drcha);
        return cont;
    }
    else
        return 0;
}

//--------------------------------------------------------------------

template<class Tbase>
bool ArbolGeneral<Tbase>::soniguales(const nodo * n1, const nodo * n2) const{
    // Si los nodos son ambos nulos o validos se continua.
    if( (n1 != NULL) == (n2 != NULL)){
        if(n1){
            // Se comprueba que las etiquetas no son iguales.
            // se rompe la recursividad si lo fueran.
            if(n1->etiqueta != n2->etiqueta){
                return false;
            }
            // Hijo-izquierda
            if(!soniguales(n1->izqda, n2->izqda))
                // Rompe si no son iguales
                return false;
            // Hermano-derecha
            if(!soniguales(n1->drcha, n2->drcha))
                return false;

        }
        // Si se llega a este punto es que los subarboles son iguales.
        return true;
    }

    else
        return false;
}

/******************************
*       Constructores         *
******************************/

template<class Tbase>
ArbolGeneral<Tbase>::ArbolGeneral(){
    laraiz = NULL;
}

//--------------------------------------------------------------------

template<class Tbase>
ArbolGeneral<Tbase>::ArbolGeneral(const Tbase& e){
    laraiz = new nodo(e);
}

//--------------------------------------------------------------------

template<class Tbase>
ArbolGeneral<Tbase>::ArbolGeneral(const ArbolGeneral<Tbase>& v){
    copiar(this->laraiz, v.laraiz);
}

//--------------------------------------------------------------------

template<class Tbase>
ArbolGeneral<Tbase>::~ArbolGeneral(){
    destruir(laraiz);
}

/********************************
*       Métodos publicos        *
********************************/

template<class Tbase>
ArbolGeneral<Tbase>& ArbolGeneral<Tbase>::operator=(const ArbolGeneral<Tbase> & v){
    if (this!=&v){
        destruir(laraiz);
        copiar(laraiz, v.laraiz);
    }
        return *this;
}

//--------------------------------------------------------------------

template<class Tbase>
void ArbolGeneral<Tbase>::AsignaRaiz(const Tbase & e){
    destruir(laraiz);
    laraiz = new nodo(e);
}

//--------------------------------------------------------------------

template<class Tbase>
typename ArbolGeneral<Tbase>::Nodo ArbolGeneral<Tbase>::raiz() const{
    return laraiz;
}

//--------------------------------------------------------------------

template<class Tbase>
typename ArbolGeneral<Tbase>::Nodo ArbolGeneral<Tbase>::hijomasizquierda(const ArbolGeneral<Tbase>::Nodo n) const{
    return n->izqda;
}

//--------------------------------------------------------------------

template<class Tbase>
typename ArbolGeneral<Tbase>::Nodo ArbolGeneral<Tbase>::hermanoderecha(const ArbolGeneral<Tbase>::Nodo n) const{
    return n->drcha;
}

//--------------------------------------------------------------------

template<class Tbase>
typename ArbolGeneral<Tbase>::Nodo ArbolGeneral<Tbase>::padre(const ArbolGeneral<Tbase>::Nodo n) const{
    return n->padre;
}

//--------------------------------------------------------------------

template<class Tbase>
Tbase& ArbolGeneral<Tbase>::etiqueta(const ArbolGeneral<Tbase>::Nodo n){
    return n->etiqueta;
}

//--------------------------------------------------------------------

template<class Tbase>
void ArbolGeneral<Tbase>::asignar_subarbol(const ArbolGeneral<Tbase>& orig, const ArbolGeneral<Tbase>::Nodo nod){
    // Árbol auxiliar para la asignación.
    ArbolGeneral<Tbase> aux;
    aux.copiar(aux.laraiz, nod);
    nodo * n = this->laraiz->izqda;
    // Se procede a buscar el último hermano
    while(n->drcha)
        n = n->drcha;
    // Se inserta el arbol recientemente copiado a n como hermano-derecha.
    insertar_hermanoderecha(n, aux);
}

//--------------------------------------------------------------------

template<class Tbase>
void ArbolGeneral<Tbase>::podar_hijomasizquierda(ArbolGeneral<Tbase>::Nodo n, ArbolGeneral<Tbase>& dest){
    // Auxiliar a la raiz del subarbol a podar.
    nodo * aux = n->izqda;
    // Padre del subarbol será la raiz del nuevo árbol.
    aux->padre = dest.laraiz;
    // El nuevo hijo-izq del árbol origen es el hermano del nodo trasplantado.
    n->izqda = aux->drcha;
    // El hermano-derecha del nuevo nodo es el anterior hijo-izq del dest.
    aux->drcha = dest.laraiz->izqda;
    // Por último, el nuevo hijo-izq del arbol dest es el nodo trasplantado.
    dest.laraiz->izqda = aux;
}

//--------------------------------------------------------------------

template<class Tbase>
void ArbolGeneral<Tbase>::podar_hermanoderecha(ArbolGeneral<Tbase>::Nodo n, ArbolGeneral<Tbase>& dest){
    //Creamos un auxiliar que apunte al subarbol a trasplantar.
    nodo * aux = n->drcha;
    //El hermano mas a la derecha es saltando el nodo trasplantado.
    n->drcha = aux->drcha;
    //Establecemos su nuevo hermano derecha
    aux->drcha = dest.laraiz->izqda;
    //Y lo establecemos como hijo mas a la izquierda
    dest.laraiz->izqda = aux;
    //Finalmente el nuevo padre de aux es la raiz del destino
    aux->padre = dest.laraiz;
}

//--------------------------------------------------------------------

template<class Tbase>
void ArbolGeneral<Tbase>::insertar_hijomasizquierda(ArbolGeneral<Tbase>::Nodo n, ArbolGeneral<Tbase> & rama){
    // Se inserta el nodo completo.
    rama.laraiz->padre = n;
    // El hermano de la derecha será el anterior hijo-izquierda
    rama.laraiz->drcha = n->izqda;
    // Rama será el hijo más a la izquierda
    n->izqda = rama.laraiz;
    // Rama queda como vacío.
    rama.laraiz = NULL;
}

//--------------------------------------------------------------------

template<class Tbase>
void ArbolGeneral<Tbase>::insertar_hermanoderecha(ArbolGeneral<Tbase>::Nodo n , ArbolGeneral<Tbase>& rama){
    // En primer lugar se apunta al hermano de n y después a rama para no perder la referencia.
    rama.laraiz->drcha = n->drcha;
    n->drcha = rama.laraiz;
    rama.laraiz->padre = n->padre;
    rama.laraiz = NULL;
}

//--------------------------------------------------------------------

template<class Tbase>
void ArbolGeneral<Tbase>::clear(){
    destruir(this->laraiz);
}

//--------------------------------------------------------------------

template<class Tbase>
int ArbolGeneral<Tbase>::size() const{
    return contar(this->laraiz);
}

//--------------------------------------------------------------------

template<class Tbase>
bool ArbolGeneral<Tbase>::empty() const{
    // Se hace así en lugar de con contar() para eficiencia O(1)
    return laraiz == NULL;
}

#endif
