 /**
 * @file refranes.cpp
 * @brief Implementación de la clase Refrán
 *
 * @author Mario Rodríguez Ruiz
 * @date Diciembre 2016
 */

#include "refranes.h"

/*******************************
*      Metodos privados        *
*******************************/

// void Refranes::AsignaRefran(ArbolGeneral<info>::Nodo n, string refran){
//     if(refran.size() > 0){
//         if(!ab.hijomasizquierda(n)){//Si no tiene hijos a la izquierda se mete directamente
//             //Inicializamos un árbol, O(1)
//             ArbolGeneral<info> a;
//             //Le asignamos como raíz el nodo a meter, también O(1)
//             a.AsignaRaiz(
//                 //Si refran.size() == 1 term es true, si no es false
//                 info(refran[0],refran.size() == 1 ? true : false)
//             );
//             //Metemos el subárbol con el nodo deseado en nuestro árbol.
//             //También O(1) ya que siempre metemos árbol de tamaño 1.
//             ab.insertar_hijomasizquierda(n,a);
//             //Llamamos recursivamente quitando la letra que acabamos de meter y con raíz el nuevo nodo.
//             AsignaRefran(ab.hijomasizquierda(n), refran.substr(1));
//             ++caracteres_almacenados ;
//         }else{
//             //Nos pasamos al primer hijo
//             n = ab.hijomasizquierda(n);
//             //Nos movemos en anchura mientras no coincida la letra y hayan hermanos disponibles
//             while((ab.etiqueta(n).c != refran[0]) &&
//                   (ab.hermanoderecha(n)) &&
//                   (ab.etiqueta(ab.hermanoderecha(n)).c <= refran[0]) //Esta comprobacion/hay que hacerla despues de ver si tiene hermano derecha, ya que si no lo tiene y no corta la comprobación nos meterá un fallo de segmentación.
//             ){
//                 n = ab.hermanoderecha(n);
//             }
//             //Si coincide la letra, llamamos recursivamente
//             if(ab.etiqueta(n).c == refran[0]){
//                 AsignaRefran(n, refran.substr(1));
//             }else{
//             //En caso contrario hemos llegado al final del nivel sin encontrarla,
//             //o la siguiente letra es mayor alfabéticamente, así que hay que
//             //insertar un nuevo subárbol a la derecha.
//                 //Inicializamos un árbol, O(1)
//                 ArbolGeneral<info> a;
//                 //Le asignamos como raíz el nodo a meter, también O(1)
//                 a.AsignaRaiz(
//                     //Si refran.size() == 1 term es true, si no es false
//                     info(refran[0],refran.size() == 1 ? true : false)
//                 );
//                 //Colocamos el subárbol como hermano a la derecha
//                 ab.insertar_hermanoderecha(n,a);
//                 n = ab.hermanoderecha(n);
//                 //Y llamamos recursivamente sobre dicho subárbol con la cadena restante
//                 AsignaRefran(n, refran.substr(1));
//                 ++n_ref ;
//                 ++caracteres_almacenados ;
//             }
//         }
//         ++caracteres_totales ;
//     }
// }

/******************************
*       Constructores         *
******************************/

//El refran vacío solo tiene una raíz, que no contiene nada.
Refranes::Refranes(){
    ab.AsignaRaiz("") ;
    n_ref = 1 ;
    caracteres_almacenados = 0 ;
    caracteres_totales = 0 ;
    numero_nodos = 1 ;
}

Refranes::Refranes(int lpre){
    len_prefijo = lpre ;
    n_ref = 1 ;
    ab.AsignaRaiz("") ;
    caracteres_almacenados = 0 ;
    caracteres_totales = 0 ;
    numero_nodos = 1 ;
}

//--------------------------------------------------------------------------------

/********************************
*       Metodos publicos        *
********************************/

int Refranes::size() const{
    return n_ref ;
//     int refrans = 0;
//     ArbolGeneral<info>::const_iter_preorden itbeg = ab.begin();
//     ArbolGeneral<info>::const_iter_preorden itend = ab.end();
//     while(itbeg != itend){
//         //Si el nodo contiene una terminacion de refran, se suma uno.
//         if((*itbeg).term) refrans++;
//         ++itbeg;
//     }
//     return refrans;
}

//--------------------------------------------------------------------------------

// string Refranes::ObtenerRefranAleatorio(){
//     srand( time(0));
//     // Se crea una posición aleatoria para obtener un refrán.
//     int pos = rand() % size() + 1 ;
// //     cout << pos << endl ;
//     // Posición que se incrementará al recorrer cada uno de
//     // los refranes.
//     int pos_bucle = 1 ;
//
//     iterator itbeg = begin();
//     iterator itend = end();
//     //El vector a devolver
//     string result = "";
//     while(itbeg != itend && result == ""){
//         // Si es term y las posiciones coinciden
//         // ya se obtiene el refrán aleatorio.
//         // sino, se incrementa la variable de posición.
//         if(pos_bucle == pos && (*itbeg.it).term){
//             result = itbeg.cad ;
//             // Se borra este refrán para que no vuelva a aparecer.
// //             BorrarRefran(result) ;
//         }
//         else if((*itbeg.it).term)
//             ++pos_bucle ;
//
//         ++itbeg;
//     }
//     return result;
// }

//--------------------------------------------------------------------------------

void Refranes::AsignaRefran(ArbolGeneral<string>::Nodo n, string refran, int nivel){
    int pos_ref = 0 ;
    string aux = "" ;
    int aux_len = nivel ;
    if(refran.size() > 0){
        if(!ab.hijomasizquierda(n)){//Si no tiene hijos a la izquierda se mete directamente
            //Inicializamos un árbol, O(1)
            for(int i = 0 ; i < aux_len ; i++){
                ArbolGeneral<string> a;
                aux.push_back(refran[pos_ref]) ;
                //Le asignamos como raíz el nodo a meter, también O(1)
                a.AsignaRaiz(aux) ;
                //Metemos el subárbol con el nodo deseado en nuestro árbol.
                //También O(1) ya que siempre metemos árbol de tamaño 1.
                ab.insertar_hijomasizquierda(n,a);
                //Llamamos recursivamente quitando la letra que acabamos de meter y con raíz el nuevo nodo.
                pos_ref++ ;
                aux.clear() ;
                n = ab.hijomasizquierda(n) ;
                ++caracteres_almacenados ;
            }
            ArbolGeneral<string> a;
            if(aux_len<=0)
                aux_len = 0 ;
            a.AsignaRaiz(refran.substr(aux_len)) ;
            ab.insertar_hijomasizquierda(n,a);
            caracteres_almacenados+=refran.substr(aux_len).size() ;
        }
        else{
            int subs = 0 ;
            n = ab.hijomasizquierda(n);
            aux.clear() ;
            if(aux_len!=0){
                aux.push_back(refran[0]) ;
                subs = 1 ;
            }
            else{
                aux+=refran ;
                subs = refran.size() ;
            }
            //Nos movemos en anchura mientras no coincida la letra y hayan hermanos disponibles
            while((ab.etiqueta(n) != aux) &&
                  (ab.hermanoderecha(n)) &&
                  (ab.etiqueta(ab.hermanoderecha(n)) <= aux) //Esta comprobacion/hay que hacerla despues de ver si tiene hermano derecha, ya que si no lo tiene y no corta la comprobación nos meterá un fallo de segmentación.
            ){
                n = ab.hermanoderecha(n);
            }
            //Si coincide la letra, llamamos recursivamente
            if(ab.etiqueta(n) == aux){
                AsignaRefran(n, refran.substr(1), aux_len-1);
            }else{
            //En caso contrario hemos llegado al final del nivel sin encontrarla,
            //o la siguiente letra es mayor alfabéticamente, así que hay que
            //insertar un nuevo subárbol a la derecha.
                //Inicializamos un árbol, O(1)
                ArbolGeneral<string> a;
                //aux.clear() ;

                //Le asignamos como raíz el nodo a meter, también O(1)
                a.AsignaRaiz(aux) ;
                //Colocamos el subárbol como hermano a la derecha
                ab.insertar_hermanoderecha(n,a);
                n = ab.hermanoderecha(n);
                //Y llamamos recursivamente sobre dicho subárbol con la cadena restante
                if(nivel > 0)
                    AsignaRefran(n, refran.substr(subs), aux_len-1);
                ++n_ref ;
            }
        }
        ++caracteres_totales ;
    }
}

void Refranes::Insertar(const string & refran){
    AsignaRefran(ab.raiz(), refran, len_prefijo) ;
}

//--------------------------------------------------------------------------------

pair<bool, Refranes::iterator> Refranes::Esta(const string &refran){
    pair<bool, iterator> res ;
    iterator iter = begin();
    iterator itend = end();
    bool esta = false;
    res.first = esta ;

    while(iter != itend && !esta){
        if((*iter) == refran && (iter).terminal()){
            esta = true;
            res.first = esta ;
            res.second = iter ;
        }
        ++iter;
    }

    return res ;
}

//--------------------------------------------------------------------------------

void Refranes::BorrarRefran(const string &refran){
//     pair<bool, iterator> res = Esta(refran) ;
//
//     if(res.first){
//         ab.destruir(*res.second.ab.it) ;
//         --n_ref ;
//     }

}

//--------------------------------------------------------------------------------
int Refranes::Caracteres_Refranes()const{
    return caracteres_totales ;
}

//--------------------------------------------------------------------------------

int Refranes::Caracteres_Almacenados(){
    return caracteres_almacenados ;
}

//--------------------------------------------------------------------------------

int Refranes::Numero_Nodos()const{
    return numero_nodos ;
}


/*******************************
*       Metodos iterator       *
*******************************/

string & Refranes::iterator::operator*(){
    return cad;
}

string & Refranes::const_iterator::operator*(){
    return cad;
}

//--------------------------------------------------------------------------------

typename Refranes::iterator & Refranes::iterator::operator++(){
    if (terminal())
	{
		++it;

		int level_actual = it.getlevel();

		// Si el nivel es 0 es que estamos al final del arbol (ha vuelto a a la raiz)
		if (level_actual == 0 || !it)
		{
			cad = "";  //mantiene los caracteres desde el nivel 1 hasta donde se encuentra it.
			level = 0;

			return *this;
		}

		if (level_actual > level)
		{
			cad += ((*it));
			level++;
		}
		else if (level_actual <= level_max)
		{
			int diff =  level_max - level_actual;

			cad.erase(cad.begin()+diff,cad.end());
            cad += ((*it));
			level = level_actual;
		}

	}
    else if(level==0){
        cad="" ;
    }

	while (!terminal())
	{
		++it;
        cad+=((*it));
        level++;
        if(primera && terminal()){
            level_max = level ;
            primera = false ;
        }
    }

    return *this;
}

typename Refranes::const_iterator & Refranes::const_iterator::operator++(){
    if (terminal())
	{
		++it;

		int level_actual = it.getlevel();

		// Si el nivel es 0 es que estamos al final del arbol (ha vuelto a a la raiz)
		if (level_actual == 0 || !it)
		{
			cad = "";  //mantiene los caracteres desde el nivel 1 hasta donde se encuentra it.
			level = 0;
			return *this;
		}

        if (level_actual <= level_max)
		{
			cad.erase(cad.begin()+level_actual,cad.end());
            cad += ((*it));
			level = level_actual;
		}

	}
    else if(level==0){
        if((*it)!="")
            cad+=((*it));
        else
            cad="" ;
        if(level_max>0){
            primera = false ;
        }
    }

	while (!terminal())
	{
		++it;
        cad+=((*it));
        level++;
        if(primera && terminal()){
            level_max = level ;
            primera = false ;
        }
    }

    return *this;
}

//--------------------------------------------------------------------------------

bool Refranes::iterator::operator==(const iterator & i) const{
    return (i.it == this->it) && (i.cad == this->cad);
}

bool Refranes::const_iterator::operator==(const const_iterator & i) const{
    return (i.it == this->it) && (i.cad == this->cad);
}

//--------------------------------------------------------------------------------

bool Refranes::iterator::operator!=(const iterator & i) const{
    return (i.it != this->it) || (i.cad != this->cad);
}

bool Refranes::const_iterator::operator!=(const const_iterator & i) const{
    return (i.it != this->it) || (i.cad != this->cad) ;
}

//--------------------------------------------------------------------------------

bool Refranes::iterator::terminal(){
    if(level>0)
        return (it).Hoja();
    else
        return false ;
}

bool Refranes::const_iterator::terminal(){
    if(level>0)
        return (it).Hoja();
    else
        return false ;
}

//--------------------------------------------------------------------------------

typename Refranes::iterator Refranes::begin(){
    iterator iter;
    iter.it = this->ab.begin();
    iter.cad = "";
    return iter;
}

typename Refranes::const_iterator Refranes::begin() const{
    const_iterator iter;
    iter.it = this->ab.begin();
    iter.cad = "";
    return iter;
}

//--------------------------------------------------------------------------------

typename Refranes::iterator Refranes::end(){
    iterator iter;
    iter.it = this->ab.end();
    iter.cad = "";
    return iter;
}

typename Refranes::const_iterator Refranes::end() const{
    const_iterator iter;
    iter.it = this->ab.end();
    iter.cad = "";
    return iter;
}


/*******************************
*      Entrada y salida        *
*******************************/

istream & operator>>(istream & is, Refranes & D){
    string refran;
    while(!is.eof()){
        getline(is, refran);
        D.Insertar(refran);
    }

    return is;
}

//--------------------------------------------------------------------------------

ostream & operator<<(ostream & os, const Refranes & D){
    Refranes::const_iterator iter = D.begin();
    Refranes::const_iterator itend = D.end();
    ++iter; //pasamos de la raíz, no nos interesa.
    while(iter != itend){
        if((iter).terminal()){
            os << (*iter) << endl;
        }
        ++iter;
    }
    return os;
}
