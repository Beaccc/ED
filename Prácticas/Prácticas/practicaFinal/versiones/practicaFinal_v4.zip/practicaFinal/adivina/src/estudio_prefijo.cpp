#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <ctype.h>
#include "refranes.h"
using namespace std;

int main(int argc, char * argv[]){
    if (argc!=3){
        cout<<"Los parametros son:"<<endl;
        cout<<"1.Dime el nombre del fichero los refranes"<<endl;
        cout<<"2.Dime el nombre del fichero de salida (en formato csv)" << endl;
        return 0;
    }

    ifstream fin(argv[1]);
    if (!fin){
        cout<<"No puedo abrir el fichero "<<argv[1]<<endl;
        return 0;
    }
    int len=3;
    if (argc==3)
    len=atoi(argv[2]);
    Refranes refs(len);
    cout<<"Creado los refranes..."<<endl;
    fin>>refs;

    cout<<"Refranes leidos!"<<endl;
    //cout<<refs<<endl;

    cout << "Número de refranes: " << refs.size() << endl ;

    cout << endl << "Prefijo" << "\t" << "Car.Total" << "\t" << "Car.Arb" << "\t" << "% Red" << "\t" << "# Nodos" << "\t" << "Red/#Nodos" << endl ;

    cout << "\t" << len << "\t" << refs.Caracteres_Refranes() << "\t" << refs.Caracteres_Almacenados() << "\t" << 0 << "\t" << refs.Numero_Nodos() << "\t" << 0 << endl ;

}  
