/**
 * @file ArbolGeneral.cpp Implementación del T.D.A. ArbolGeneral
 *
 * @author Mario Rodríguez Ruiz
 * @date Diciembre 2016
 *
 */

/********************************************************/
/* 	            Métodos asociados a nodo                */
/********************************************************/

template <class Tbase>
void ArbolGeneral<Tbase>::copiar(ArbolGeneral<Tbase>::nodo * &dest, const ArbolGeneral<Tbase>::nodo*const &source){
    if (source!=0){
        dest=new nodo(source->et);
        copiar(dest->izqda,source->izqda);
        if (dest->izqda!=0){
            dest->izqda->padre= dest;
        }
        copiar(dest->drcha,source->drcha);
        if (dest->drcha!=0)
            dest->drcha->padre=dest;
    }
    else dest=0;
}

//--------------------------------------------------------------------

template <class Tbase>
void ArbolGeneral<Tbase>::destruir(ArbolGeneral<Tbase>::nodo *&d){
    if (d!=0){
        destruir(d->izqda);
        destruir(d->drcha);
        delete d;
    }
}

//--------------------------------------------------------------------

template <class Tbase>
int ArbolGeneral<Tbase>::contar(const ArbolGeneral<Tbase>::nodo*d)const{
    if (d==0) return 0;
    else return 1+contar(d->izqda)+contar(d->drcha);
}

//--------------------------------------------------------------------

template <class Tbase>
bool ArbolGeneral<Tbase>::soniguales(const ArbolGeneral<Tbase>::nodo *s1,const ArbolGeneral<Tbase>::nodo *s2)const {
    if (s1==0 && s2==0)
        return true;
    else
    if (s1==0 || s2==0)
        return false;
    if (s1->et!=s2->et)
        return false;
    else
        return soniguales(s1->izqda,s2->izqda) && soniguales(s1->drcha,s2->drcha);
}

//--------------------------------------------------------------------

template <class Tbase>
void ArbolGeneral<Tbase>::insertar_hijomasizquierda(Nodo n, ArbolGeneral<Tbase>& rama){
    //metemos el arbol entero
    rama.laraiz->padre = n;
    //establecemos su hermano a la derecha el anterior hijo-izquierda
    rama.laraiz->drcha = n->izqda;
    //hacemos que rama sea el hijo mas a la izquierda
    n->izqda = rama.laraiz;
    //el arbol rama queda vacío
    rama.laraiz = NULL;
}

//--------------------------------------------------------------------

template <class Tbase>
void ArbolGeneral<Tbase>::insertar_hermanoderecha(Nodo n, ArbolGeneral<Tbase>& rama){
    //primero apuntamos al hermano de n y despues a rama para no perder la referencia
    rama.laraiz->drcha = n->drcha;
    n->drcha = rama.laraiz;
    rama.laraiz->padre = n->padre;
    //el arbol rama queda nulo
    rama.laraiz = NULL;
}

//--------------------------------------------------------------------

template <class Tbase>
void ArbolGeneral<Tbase>::podar_hijomasizquierda(Nodo n, ArbolGeneral<Tbase>& dest){
    //Puntero auxiliar a la raiz del subarbol a podar.
    nodo * aux = n->izqda;
    //Establecemos el padre del subarbol como la raiz del nuevo arbol
    aux->padre = dest.laraiz;
    //El nuevo hijo-izq del arbol origen es el hermano del nodo trasplantado.
    n->izqda = aux->drcha;
    //Y el hermano-derecha del nodo trasplantado es el anterior hijo-izq del dest.
    aux->drcha = dest.laraiz->izqda;
    //Finalmente el nuevo hij-izq del arbol dest es el nodo trasplantado.
    dest.laraiz->izqda = aux;
}

//--------------------------------------------------------------------

template <class Tbase>
void ArbolGeneral<Tbase>::podar_hermanoderecha(Nodo n, ArbolGeneral<Tbase>& dest){
	// Se crea un uxiliar que apunte al subarbol a trasplantar.
    nodo * aux = n->drcha;
    // El hermano mas a la derecha es saltando el nodo trasplantado.
    n->drcha = aux->drcha;
    //Establecemos su nuevo hermano derecha
    aux->drcha = dest.laraiz->izqda;
    //Y lo establecemos como hijo mas a la izquierda
    dest.laraiz->izqda = aux;
    //Finalmente el nuevo padre de aux es la raiz del destino
    aux->padre = dest.laraiz;
}

//--------------------------------------------------------------------

template <class Tbase>
void ArbolGeneral<Tbase>::lee_arbol(istream & is,ArbolGeneral<Tbase>::nodo *&n){
    char c;
    c=is.get();
    if (is){
        if (c=='x')
            n=0;
        else{
            if (c=='n'){
                Tbase e;
                is>>e;

                n= new nodo(e);
                lee_arbol(is,n->izqda);
                lee_arbol(is,n->drcha);
                if (n->izqda!=0)
                        n->izqda->padre=n;
                if (n->drcha!=0)
                        n->drcha->padre=n;
            }
        }
    }
}

//--------------------------------------------------------------------

template <class Tbase>
void ArbolGeneral<Tbase>::escribe_arbol(ostream & os, ArbolGeneral<Tbase>::nodo *n)const {
	char c;

	if (n==0)
        os<<'x';
	else{
        os<<'n'<<n->et;
        escribe_arbol(os,n->izqda);
        escribe_arbol(os,n->drcha);
	}
}

/********************************************************/
/* 	        Métodos de ArbolGeneral                     */
/********************************************************/

template <class Tbase>
ArbolGeneral<Tbase>::ArbolGeneral(){
    laraiz = 0;
}

//--------------------------------------------------------------------

template <class Tbase>
ArbolGeneral<Tbase>::ArbolGeneral(const Tbase &e){
    laraiz=new nodo(e);
}

//--------------------------------------------------------------------

template <class Tbase>
ArbolGeneral<Tbase>::ArbolGeneral(const ArbolGeneral<Tbase> & ab){
    if (ab.laraiz==0)
        laraiz=0;
    else
        copiar(laraiz,ab.laraiz);
}

//--------------------------------------------------------------------

template <class Tbase>
ArbolGeneral<Tbase>::~ArbolGeneral(){
    destruir(laraiz);
}

//--------------------------------------------------------------------

template <class Tbase>
ArbolGeneral<Tbase> & ArbolGeneral<Tbase>::operator=(const ArbolGeneral<Tbase> & ab){
    if (this!=&ab){
        destruir(laraiz);
        copiar(laraiz, ab.laraiz);
    }
        return *this;
}

//--------------------------------------------------------------------

template<class Tbase>
void ArbolGeneral<Tbase>::AsignaRaiz(const Tbase & e){
    destruir(laraiz);
    laraiz = new nodo(e);
}

//--------------------------------------------------------------------
template<class Tbase>
typename ArbolGeneral<Tbase>::Nodo ArbolGeneral<Tbase>::raiz() const{
    return laraiz;
}

//--------------------------------------------------------------------

template<class Tbase>
typename ArbolGeneral<Tbase>::Nodo ArbolGeneral<Tbase>::hijomasizquierda(const ArbolGeneral<Tbase>::Nodo n) const{
    return n->izqda;
}

//--------------------------------------------------------------------

template<class Tbase>
typename ArbolGeneral<Tbase>::Nodo ArbolGeneral<Tbase>::hermanoderecha(const ArbolGeneral<Tbase>::Nodo n) const{
    return n->drcha;
}

//--------------------------------------------------------------------

template<class Tbase>
typename ArbolGeneral<Tbase>::Nodo ArbolGeneral<Tbase>::padre(const ArbolGeneral<Tbase>::Nodo n) const{
    return n->padre;
}

//--------------------------------------------------------------------

template<class Tbase>
Tbase& ArbolGeneral<Tbase>::etiqueta(const ArbolGeneral<Tbase>::Nodo n){
    return n->etiqueta;
}

//--------------------------------------------------------------------

template<class Tbase>
const Tbase& ArbolGeneral<Tbase>::etiqueta(const ArbolGeneral<Tbase>::Nodo n) const{
    return n->etiqueta;
}

//--------------------------------------------------------------------

template <class T>
void ArbolGeneral<T>::asignar_subarbol(const ArbolGeneral<T>& orig,
 const Nodo nod){
	destruir(laraiz);    // Destruye el árbol actual
	copiar(laraiz,nod);  // Copia el subárbol de nod en la raíz
	// Si el subárbol no está vacío,
    // se actualiza el padre
    if (laraiz!=0)
		laraiz->padre=0;
}

//--------------------------------------------------------------------

template <class Tbase>
void ArbolGeneral<Tbase>::clear(){
    destruir(laraiz);
    laraiz=0;
}

//--------------------------------------------------------------------

template <class Tbase>
bool ArbolGeneral<Tbase>::empty()const {
    return laraiz==0;
}

//--------------------------------------------------------------------

template <class Tbase>
int ArbolGeneral<Tbase>::size()const {
    return contar(laraiz);
}

//--------------------------------------------------------------------

template <class Tbase>
bool ArbolGeneral<Tbase>::operator==(const ArbolGeneral<Tbase> &a)const {
    return soniguales(laraiz, a.laraiz);
}

//--------------------------------------------------------------------

template <class Tbase>
bool ArbolGeneral<Tbase>::operator!=(const ArbolGeneral<Tbase> &a)const{
    return !(*this==a);
}

//--------------------------------------------------------------------

template<class Tbase>
bool ArbolGeneral<Tbase>::iter_preorden::operator!(){
    return !it;
}

//--------------------------------------------------------------------

template<class Tbase>
bool ArbolGeneral<Tbase>::const_iter_preorden::operator!(){
    return !it;
}

/************OPERACIONES DE LECTURA Y ESCRITURA***********************/
template <class Tbase>
ostream & operator<<(ostream &os,const ArbolGeneral<Tbase> &ab){
    ab.Escribe(os,ab.laraiz);
    return os;
}
template <class Tbase>
istream & operator>>(istream &is,ArbolGeneral<Tbase>&ab){
    ab.Lee(is,ab.laraiz);
    return is;
}
