/**
 * @file Refranes.cpp Implementación del T.D.A. Refranes
 *
 * @author Mario Rodríguez Ruiz
 * @date Diciembre 2016
 *
 */

#include "refranes.h"

/********************************************************/
/* 	                Métodos privados                    */
/********************************************************/



/********************************************************/
/* 	                Métodos públicos                    */
/********************************************************/

Refranes::Refranes(){
    len_prefijo = 3 ;
    ab.AsignaRaiz(info('\0',false));
}

//--------------------------------------------------------------------

Refranes::Refranes(int lpre){
    len_prefijo = lpre ;
}

//--------------------------------------------------------------------

int Refranes::size() const{
    return n_ref ;
}

//--------------------------------------------------------------------

void Refranes::AsignaPalabra(ArbolGeneral<info>::Nodo n, string palabra){
    if(palabra.size() > 0){
        if(!ab.hijomasizquierda(n)){//Si no tiene hijos a la izquierda se mete directamente
            //Inicializamos un árbol, O(1)
            ArbolGeneral<info> a;
            //Le asignamos como raíz el nodo a meter, también O(1)
            a.AsignaRaiz(
                //Si palabra.size() == 1 term es true, si no es false
                info(palabra[0],palabra.size() == 1 ? true : false)
            );
            //Metemos el subárbol con el nodo deseado en nuestro árbol.
            //También O(1) ya que siempre metemos árbol de tamaño 1.
            ab.insertar_hijomasizquierda(n,a);
            //Llamamos recursivamente quitando la letra que acabamos de meter y con raíz el nuevo nodo.
            AsignaPalabra(ab.hijomasizquierda(n), palabra.substr(1));
        }else{
            //Nos pasamos al primer hijo
            n = ab.hijomasizquierda(n);
            //Nos movemos en anchura mientras no coincida la letra y hayan hermanos disponibles
            while((ab.etiqueta(n).c != palabra[0]) &&
                  (ab.hermanoderecha(n)) &&
                  (ab.etiqueta(ab.hermanoderecha(n)).c <= palabra[0]) //Esta comprobacion/hay que hacerla despues de ver si tiene hermano derecha, ya que si no lo tiene y no corta la comprobación nos meterá un fallo de segmentación.
            ){
                n = ab.hermanoderecha(n);
            }
            //Si coincide la letra, llamamos recursivamente
            if(ab.etiqueta(n).c == palabra[0]){
                AsignaPalabra(n, palabra.substr(1));
            }else{
            //En caso contrario hemos llegado al final del nivel sin encontrarla,
            //o la siguiente letra es mayor alfabéticamente, así que hay que
            //insertar un nuevo subárbol a la derecha.
                //Inicializamos un árbol, O(1)
                ArbolGeneral<info> a;
                //Le asignamos como raíz el nodo a meter, también O(1)
                a.AsignaRaiz(
                    //Si palabra.size() == 1 term es true, si no es false
                    info(palabra[0],palabra.size() == 1 ? true : false)
                );
                //Colocamos el subárbol como hermano a la derecha
                ab.insertar_hermanoderecha(n,a);
                n = ab.hermanoderecha(n);
                //Y llamamos recursivamente sobre dicho subárbol con la cadena restante
                AsignaPalabra(n, palabra.substr(1));
            }
        }
    }
}

void Refranes::Insertar(const string & refran){
    AsignaPalabra(ab.raiz(), refran) ;


}

//--------------------------------------------------------------------

void Refranes::BorrarRefran(const string & refran){

}

//--------------------------------------------------------------------

int Refranes::Caracteres_Refranes() const{
    return caracteres_totales ;
}

//--------------------------------------------------------------------

int Refranes::Caracteres_Almacenados(){
    return 0 ;
}

//--------------------------------------------------------------------

int Refranes::Numero_Nodos() const{
    return 0 ;
}


/********************************************************/
/* 	                Métodos de iteradores               */
/********************************************************/



//--------------------------------------------------------------------

string & Refranes::iterator::operator*(){
    return cad;
}

string & Refranes::const_iterator::operator*(){
    return cad;
}

//--------------------------------------------------------------------

typename Refranes::iterator & Refranes::iterator::operator++(){
    int prevlevel = it.getlevel();
    ++it;
    if(!it){//si hemos llegado al final del árbol devolvemos end()
        cad = "";
    }else if(prevlevel >= it.getlevel()){
        cad.replace(cad.end() - ((prevlevel + 1) - it.getlevel()), cad.end(), 1, (*it).c);
    }
    else{
        cad.push_back((*it).c);
    }
    return *this;
}

typename Refranes::const_iterator & Refranes::const_iterator::operator++(){
    int prevlevel = it.getlevel();
    ++it;
    if(!it){//si hemos llegado al final del árbol devolvemos end()
        cad = "";
    }else if(prevlevel >= it.getlevel()){
        cad.replace(cad.end() - ((prevlevel + 1) - it.getlevel()), cad.end(), 1, (*it).c);
    }
    else{
        cad.push_back((*it).c);
    }
    return *this;
}

//--------------------------------------------------------------------

bool Refranes::iterator::operator==(const iterator & i) const{
    return i.cad == cad && it==i.it;
}

bool Refranes::const_iterator::operator==(const const_iterator & i) const{
    return i.cad == cad && it==i.it;
}

//--------------------------------------------------------------------

bool Refranes::iterator::operator!=(const iterator & i) const{
    return i.cad != cad || it!=i.it;
}

bool Refranes::const_iterator::operator!=(const const_iterator & i) const{
    return i.cad != cad || it!=i.it;
}

//--------------------------------------------------------------------

// bool Refranes::iterator::terminal(){
//     return (*it).term;
// }

//--------------------------------------------------------------------

Refranes::iterator Refranes::begin(){
    iterator iter;
    iter.it = this->ab.begin();
    iter.cad = "";
    return iter;
}

Refranes::const_iterator Refranes::begin() const{
    const_iterator iter;
    iter.it = this->ab.begin();
    iter.cad = "";
    return iter;
}

//--------------------------------------------------------------------

Refranes::iterator Refranes::end(){
    iterator iter;
    iter.it = this->ab.end();
    iter.cad = "";
    return iter;
}

Refranes::const_iterator Refranes::end() const{
    const_iterator iter;
    iter.it = this->ab.end();
    iter.cad = "";
    return iter;
}

/********************************************************/
/* 	                   Operadores                       */
/********************************************************/

istream & operator>>(istream &is, Refranes &R){
    string frase;
    while(!is.eof()){
        std::getline(is, frase) ;
        R.Insertar(frase) ;
    }

    return is;
}

//--------------------------------------------------------------------

ostream & operator<<(ostream &os,const Refranes &R){
    Refranes::const_iterator iter = R.begin();
    Refranes::const_iterator itend = R.end();
    ++iter; //pasamos de la raíz, no nos interesa.
    while(iter != itend){
        if(iter.terminal()){
            os << (*iter) << endl;
        }
        ++iter;
    }
    return os;
}

//--------------------------------------------------------------------
//--------------------------------------------------------------------
//--------------------------------------------------------------------
//--------------------------------------------------------------------
//--------------------------------------------------------------------
//--------------------------------------------------------------------
//--------------------------------------------------------------------
//--------------------------------------------------------------------
