var structCelda =
[
    [ "Celda", "structCelda.html#a9195864bae6b5a4bbefb60bd8965a7c2", null ],
    [ "elem", "structCelda.html#a4ae2327e3d2c3c426c5d5a71c59d9544", null ],
    [ "sig", "structCelda.html#a21d45c0a09e1129e74971adcb8f96919", null ]
];