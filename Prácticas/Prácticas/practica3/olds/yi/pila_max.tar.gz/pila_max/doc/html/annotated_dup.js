var annotated_dup =
[
    [ "Celda", "structCelda.html", "structCelda" ],
    [ "Cola", "classCola.html", "classCola" ],
    [ "elemento", "structelemento.html", "structelemento" ],
    [ "Iterador", "classIterador.html", "classIterador" ],
    [ "Lista", "classLista.html", "classLista" ],
    [ "Pila_max", "classPila__max.html", "classPila__max" ],
    [ "VD", "classVD.html", "classVD" ]
];