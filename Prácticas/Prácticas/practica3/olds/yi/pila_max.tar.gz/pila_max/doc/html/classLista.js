var classLista =
[
    [ "Lista", "classLista.html#adce924e21607848663132290be1a959d", null ],
    [ "Lista", "classLista.html#a5c8b139a503fc07bdf5c8fb7ccbaca29", null ],
    [ "~Lista", "classLista.html#af297975e278b0c92cbf67d14b2f08366", null ],
    [ "back", "classLista.html#ae79d368b33629e334bc74c7c43fee8a3", null ],
    [ "begin", "classLista.html#a5329b45219eaf306b28c3ce7f309ac78", null ],
    [ "Borrar", "classLista.html#aba7b172959d3d84e59d9f409678cd95a", null ],
    [ "Copiar", "classLista.html#a6bba5ea57f62a207b2c38c4dc848abe3", null ],
    [ "end", "classLista.html#aa651877ce5f8f1b2bf65087ae5adac0b", null ],
    [ "front", "classLista.html#a412b7776b838ef2e483a8f181a223786", null ],
    [ "Get", "classLista.html#a5bf4fa385b4d0e6038d2dfcba5eea910", null ],
    [ "Insertar", "classLista.html#a46866fc0097ea39e58866fab241f4cc5", null ],
    [ "Set", "classLista.html#a34910e9ba1639fa6c8de40867858a095", null ],
    [ "Vacia", "classLista.html#a681ac2d3562a5362de6e18df0d229e9d", null ],
    [ "_cab", "classLista.html#ac463786f33c9be952ab22ddd51a57509", null ],
    [ "_ultima", "classLista.html#a02052371c5048b64a848a77dad25ac39", null ]
];