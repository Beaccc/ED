var pila__max__cola_8h =
[
    [ "Pila_max", "classPila__max.html", "classPila__max" ],
    [ "operator<<", "pila__max__cola_8h.html#ae38a85af4482dca49385dcc635538b8d", null ]
];