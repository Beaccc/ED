var classIterador =
[
    [ "Iterador", "classIterador.html#a95667696efab8089c63826a5fe3d23bc", null ],
    [ "operator!=", "classIterador.html#a765732282cc0ba53b3833d4020e0193a", null ],
    [ "operator*", "classIterador.html#a2f4bc6b4cacfa8022ea835e22c1f7848", null ],
    [ "operator++", "classIterador.html#ae56e6d741bbfc1f2b3c5a236817f8ea4", null ],
    [ "operator==", "classIterador.html#afd183da1bd64550d19154248914b292f", null ],
    [ "Lista< T >", "classIterador.html#aaf51eba006c8c436041f4a80ac819c75", null ],
    [ "ptr", "classIterador.html#ae36a86bb2f276dcad8c7c035270da05e", null ]
];