var classVD =
[
    [ "VD", "classVD.html#a85d6e04a09adabaefe28fc440f4d9102", null ],
    [ "VD", "classVD.html#a74d379eb3ca2ef5f715624222bba5d71", null ],
    [ "~VD", "classVD.html#a0533f99aa2fee31fde63edd6c4b8bb2d", null ],
    [ "Borrar", "classVD.html#a4db2e1e8dc098cc385001867ac63cc51", null ],
    [ "Insertar", "classVD.html#ad9c2b95e8f81164ee23eee1b96160b9f", null ],
    [ "operator=", "classVD.html#a645b65a6343059cd921f6a2856c97249", null ],
    [ "operator[]", "classVD.html#a7cd05cb587b7889fcb4b30e20230f6ab", null ],
    [ "pop_back", "classVD.html#a5cee83ea68939fb432dedadb2e5eb605", null ],
    [ "push_back", "classVD.html#af569c70d43bdb92bbe1909f3b6022d0c", null ],
    [ "resize", "classVD.html#acdfc22a424a36b17d2a231620be866ba", null ],
    [ "size", "classVD.html#ac0c36870b58a1b422df1aca6fa299a49", null ],
    [ "Vacia", "classVD.html#aa2961de99fd5f655defed9b2698030f6", null ],
    [ "_cap", "classVD.html#a03e1ffe786b532c0f8828ae0f633a7e3", null ],
    [ "_datos", "classVD.html#a4aefc67c4ca7d3ae193a483851847ca7", null ],
    [ "_size", "classVD.html#a291a1c90a175c8bf31fd3855ef6398c2", null ]
];