var structelemento =
[
    [ "elem", "structelemento.html#a1091d61f673bc3cc81c68e8156b25537", null ],
    [ "max", "structelemento.html#ad788dc2f06ae38ba1c1a3fbe5464443d", null ]
];