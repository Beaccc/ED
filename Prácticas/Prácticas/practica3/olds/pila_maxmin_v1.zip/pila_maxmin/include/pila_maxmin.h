#define CUAL_COMPILA 1

/**
 * @brief Estructura que guarda cada elemento de la pila.
 * Cada elemento guarda un entero, un valor máximo (máximo
 * de la pila hasta el momento) y un valor mínimo (mínimo
 * de la pila hasta el momento).
*/


struct elemento{
    int elem;   /**< Valor del elemento de la pila */
    int max;    /**< Valor máximo en la pila */
    int min;    /**< Valor mínimo en la pila */
};

#if CUAL_COMPILA == 1
    #include "pila_maxmin_VD.h"
#elif CUAL_COMPILA == 2
    #include "pila_maxmin_list.h"
#elif CUAL_COMPILA == 3
    #include "pila_maxmin_cola.h"
#endif

