var classLista =
[
    [ "Lista", "classLista.html#adce924e21607848663132290be1a959d", null ],
    [ "Lista", "classLista.html#a5c8b139a503fc07bdf5c8fb7ccbaca29", null ],
    [ "~Lista", "classLista.html#af297975e278b0c92cbf67d14b2f08366", null ],
    [ "back", "classLista.html#aced1b407ecdfbbdb584aa00f124bac7a", null ],
    [ "begin", "classLista.html#ab0f3e6cb5ab07ea9dc82cf29c8d28410", null ],
    [ "borrar", "classLista.html#a9ed71be43938b02ef01c499ada681158", null ],
    [ "copiar", "classLista.html#aa8c0838ae796cd5667ed96ec063acb04", null ],
    [ "end", "classLista.html#a6bce36325c6591f751c02dee3e243751", null ],
    [ "front", "classLista.html#a1501278d4b7a6646228bc93b75b63310", null ],
    [ "get", "classLista.html#a3eafb22dbc5fae21bb6010145771af3d", null ],
    [ "insertar", "classLista.html#ab64c189dcb712c8714a0b5c25358fca3", null ],
    [ "set", "classLista.html#a5372808566dd8ccc5344698393430391", null ],
    [ "vacia", "classLista.html#a606aa2f4de2b37f7503ced779a569431", null ],
    [ "_cab", "classLista.html#ac463786f33c9be952ab22ddd51a57509", null ],
    [ "_ultima", "classLista.html#a02052371c5048b64a848a77dad25ac39", null ]
];