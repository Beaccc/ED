var annotated_dup =
[
    [ "Celda", "structCelda.html", "structCelda" ],
    [ "Cola", "classCola.html", "classCola" ],
    [ "elemento", "structelemento.html", "structelemento" ],
    [ "Iterador", "classIterador.html", "classIterador" ],
    [ "Lista", "classLista.html", "classLista" ],
    [ "Pila_maxmin", "classPila__maxmin.html", "classPila__maxmin" ],
    [ "VD", "classVD.html", "classVD" ]
];