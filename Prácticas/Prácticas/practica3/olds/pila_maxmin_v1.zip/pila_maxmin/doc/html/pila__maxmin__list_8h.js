var pila__maxmin__list_8h =
[
    [ "Pila_maxmin", "classPila__maxmin.html", "classPila__maxmin" ],
    [ "operator<<", "pila__maxmin__list_8h.html#ae38a85af4482dca49385dcc635538b8d", null ]
];