var classCola =
[
    [ "Celda", "structCola_1_1Celda.html", "structCola_1_1Celda" ],
    [ "Cola", "classCola.html#aea3a971c7c522618f4dc972e8b4ff153", null ],
    [ "Cola", "classCola.html#a2249ab5603a92fddb8bd9bb55abeaa24", null ],
    [ "~Cola", "classCola.html#af4d55930921c93c626006ba2e842530b", null ],
    [ "frente", "classCola.html#a1df4ad2b50116ef22e77ad3f77b02d29", null ],
    [ "frente", "classCola.html#abd603daab25efd7131049f98ea09c175", null ],
    [ "num_elementos", "classCola.html#a26e5b0df5411aa23114d790f0a8c023b", null ],
    [ "operator=", "classCola.html#a2ac480681dec95b8ffeea075507849e2", null ],
    [ "poner", "classCola.html#a4a902e5805ae74f8d80c6f3267fd14c4", null ],
    [ "quitar", "classCola.html#a320766ddc7020424052c99e5c82a105d", null ],
    [ "vacia", "classCola.html#a2c746a66289cd4f90d4e43f712b72fb6", null ],
    [ "num_elem", "classCola.html#aba9d5dd07641ceda78b84f1929cde0f4", null ],
    [ "primera", "classCola.html#a0f332c0bfe8206335b94491cf63aaa67", null ],
    [ "ultima", "classCola.html#af25f40617cc0430aab121898486a6d8d", null ]
];