#include "pila_maxmin_list.h"

bool Pila_maxmin::vacia(){
    return _pila->vacia();
}

elemento Pila_maxmin::tope(){
    if( !_pila->vacia() )
        return _pila->front();
}

void Pila_maxmin::poner(int n){
    elemento e;
    e.elem = n;
    if( _pila->vacia() ){
        e.max = n;
        _pila->insertar(_pila->begin(), e);
    }else{
        elemento f = tope();
        if(n > f.max)
            e.max = n;
        else
            e.max = f.max;
        _pila->insertar(_pila->begin(), e);
    }
}

void Pila_maxmin::quitar(){
    if( !_pila->vacia() ){
        _pila->borrar(_pila->begin());
    }
}


