#include "pila_maxmin_list.h"

bool Pila_maxmin::vacia(){
    return _pila->vacia();
}

elemento Pila_maxmin::tope(){
    if( !_pila->vacia() )
        return (*_pila)[_pila->size() - 1];
}

void Pila_maxmin::poner(int n){
    elemento e;
    e.elem = n;
    if( _pila->vacia() ){
        e.max = n;
        _pila->push_back(e);
    }else{
        elemento f = tope();
        if(n > f.max)
            e.max = n;
        else
            e.max = f.max;
        _pila->push_back(e);
    }
}

void Pila_maxmin::quitar(){
    if( !_pila->vacia() ){
        _pila->pop_back();
    }
}


